package ir.systemguard.engine

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process

/** خواندن آمار مصرف برنامه‌ها (برای اینکه برنامه‌های در حال استفاده بسته نشوند). */
object UsageHelper {

	fun hasPermission(context: Context): Boolean {
		return try {
			val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
			val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
				ops.unsafeCheckOpNoThrow(
					"android:get_usage_stats",
					Process.myUid(),
					context.packageName
				)
			} else {
				@Suppress("DEPRECATION")
				ops.checkOpNoThrow(
					"android:get_usage_stats",
					Process.myUid(),
					context.packageName
				)
			}
			mode == AppOpsManager.MODE_ALLOWED
		} catch (t: Throwable) {
			false
		}
	}

	/** بسته‌هایی که در چند دقیقه گذشته استفاده شده‌اند. */
	fun recentPackages(context: Context, minutes: Int): Set<String> {
		if (!hasPermission(context)) return emptySet()
		return try {
			val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
			val end = System.currentTimeMillis()
			val start = end - minutes * 60_000L
			val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, start, end)
			val out = HashSet<String>()
			if (stats != null) {
				for (s in stats) {
					if (s.lastTimeUsed >= start) out.add(s.packageName)
				}
			}
			out
		} catch (t: Throwable) {
			emptySet()
		}
	}
}
