package ir.systemguard.engine

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import ir.systemguard.data.Prefs

/**
 * آزادسازی رم با بستن پروسه‌های پس‌زمینهٔ برنامه‌هایی که محافطت‌شده نیستند.
 * بدون روت کار می‌کند و فقط به پروسه‌های پس‌زمینه دست می‌زند.
 */
class AppCleaner(private val context: Context) {

	class Result(val killed: Int, val scanned: Int, val freedMb: Long)

	fun clean(aggressive: Boolean): Result {
		val am = try {
			context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
		} catch (t: Throwable) {
			return Result(0, 0, 0L)
		}

		val before = availableMb(am)
		val protectedSet = ProtectedApps.build(context)
		val whitelist = Prefs.whitelist(context)
		val graceMinutes = if (aggressive) 3 else 20
		val recent = UsageHelper.recentPackages(context, graceMinutes)
		val includeSystem = Prefs.includeSystemApps(context)

		val apps: List<ApplicationInfo> = try {
			context.packageManager.getInstalledApplications(0)
		} catch (t: Throwable) {
			emptyList()
		}

		var killed = 0
		var scanned = 0

		for (info in apps) {
			val pkg = info.packageName ?: continue
			scanned++

			if (pkg == context.packageName) continue
			if (!info.enabled) continue

			val isSystem = (info.flags and
				(ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
			if (isSystem && !includeSystem) continue

			if (protectedSet.contains(pkg)) continue
			if (whitelist.contains(pkg)) continue
			if (recent.contains(pkg)) continue

			try {
				am.killBackgroundProcesses(pkg)
				killed++
			} catch (t: Throwable) {
				// برخی بسته‌ها قابل بستن نیستند
			}
		}

		try {
			System.gc()
			Thread.sleep(500L)
		} catch (t: Throwable) {
			// ignore
		}

		val after = availableMb(am)
		val freed = if (after > before) after - before else 0L

		Prefs.addFreed(context, freed)
		Prefs.bumpCleanCount(context)

		return Result(killed, scanned, freed)
	}

	private fun availableMb(am: ActivityManager): Long {
		return try {
			val mi = ActivityManager.MemoryInfo()
			am.getMemoryInfo(mi)
			mi.availMem / (1024L * 1024L)
		} catch (t: Throwable) {
			0L
		}
	}
}
