package ir.systemguard.monitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import java.io.File
import java.io.RandomAccessFile

/** خواندن وضعیت رم، پردازنده، دما و حافطه. */
object StatsCollector {

	private var prevCpuTotal = 0L
	private var prevCpuIdle = 0L
	private var procStatUsable = true
	private var cachedMaxFreq = -1

	fun sample(context: Context): StatsSnapshot {
		val mem = readMemInfo()

		var ramTotalKb = mem["MemTotal"] ?: 0L
		var ramAvailKb = mem["MemAvailable"] ?: 0L
		var lowMemory = false

		try {
			val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
			val mi = ActivityManager.MemoryInfo()
			am.getMemoryInfo(mi)
			lowMemory = mi.lowMemory
			if (ramTotalKb <= 0L) ramTotalKb = mi.totalMem / 1024L
			if (ramAvailKb <= 0L) ramAvailKb = mi.availMem / 1024L
		} catch (t: Throwable) {
			// ignore
		}

		val swapTotalKb = mem["SwapTotal"] ?: 0L
		val swapFreeKb = mem["SwapFree"] ?: 0L

		val freqs = readCoreFreqs()
		val maxFreq = readMaxFreq()

		var load = cpuLoadFromProcStat()
		var approx = false
		if (load < 0) {
			load = cpuLoadFromFreq(freqs, maxFreq)
			approx = load >= 0
		}
		if (load < 0) load = 0

		val thermalStatus = readThermalStatus(context)

		var storageFree = 0f
		var storageTotal = 0f
		try {
			val fs = StatFs(Environment.getDataDirectory().absolutePath)
			val gb = 1024f * 1024f * 1024f
			storageFree = fs.availableBytes / gb
			storageTotal = fs.totalBytes / gb
		} catch (t: Throwable) {
			// ignore
		}

		return StatsSnapshot(
			timestamp = System.currentTimeMillis(),
			ramTotalKb = ramTotalKb,
			ramAvailKb = ramAvailKb,
			lowMemory = lowMemory,
			swapTotalKb = swapTotalKb,
			swapFreeKb = swapFreeKb,
			cpuLoad = load,
			cpuLoadApprox = approx,
			coreFreqMhz = freqs,
			cpuMaxFreqMhz = maxFreq,
			cpuTempC = readCpuTemp(),
			batteryTempC = readBatteryTemp(context),
			thermalStatus = thermalStatus,
			storageFreeGb = storageFree,
			storageTotalGb = storageTotal,
			jankPerSec = JankMonitor.jankPerSec
		)
	}

	// ---------------- رم ----------------

	fun readMemInfo(): Map<String, Long> {
		val out = HashMap<String, Long>()
		try {
			File("/proc/meminfo").forEachLine { raw ->
				val line = raw.trim()
				val sep = line.indexOf(':')
				if (sep > 0) {
					val key = line.substring(0, sep)
					val rest = line.substring(sep + 1).trim()
					val num = rest.split(" ")[0].toLongOrNull()
					if (num != null) out[key] = num
				}
			}
		} catch (t: Throwable) {
			// ignore
		}
		return out
	}

	// ---------------- پردازنده ----------------

	private fun cpuLoadFromProcStat(): Int {
		if (!procStatUsable) return -1
		try {
			RandomAccessFile("/proc/stat", "r").use { raf ->
				val line = raf.readLine() ?: return -1
				val parts = line.trim().split(Regex("\\s+"))
				if (parts.size < 8 || parts[0] != "cpu") return -1

				var total = 0L
				for (i in 1 until minOf(parts.size, 9)) {
					total += parts[i].toLongOrNull() ?: 0L
				}
				val idle = (parts[4].toLongOrNull() ?: 0L) + (parts[5].toLongOrNull() ?: 0L)

				var load = -1
				if (prevCpuTotal > 0L && total > prevCpuTotal) {
					val dTotal = total - prevCpuTotal
					val dIdle = idle - prevCpuIdle
					val busy = dTotal - dIdle
					load = ((busy * 100L) / dTotal).toInt().coerceIn(0, 100)
				}
				prevCpuTotal = total
				prevCpuIdle = idle
				return load
			}
		} catch (t: Throwable) {
			procStatUsable = false
			return -1
		}
	}

	private fun cpuLoadFromFreq(freqs: List<Int>, maxFreq: Int): Int {
		if (freqs.isEmpty() || maxFreq <= 0) return -1
		var sum = 0L
		for (f in freqs) sum += f
		val avg = sum.toFloat() / freqs.size
		return ((avg / maxFreq) * 100f).toInt().coerceIn(0, 100)
	}

	private fun readCoreFreqs(): List<Int> {
		val cores = Runtime.getRuntime().availableProcessors()
		val out = ArrayList<Int>()
		for (i in 0 until cores) {
			val khz = readLongFile("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")
			if (khz != null && khz > 0) out.add((khz / 1000L).toInt())
		}
		return out
	}

	private fun readMaxFreq(): Int {
		if (cachedMaxFreq > 0) return cachedMaxFreq
		val cores = Runtime.getRuntime().availableProcessors()
		var best = 0
		for (i in 0 until cores) {
			val khz = readLongFile("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
			if (khz != null && khz > 0) {
				val mhz = (khz / 1000L).toInt()
				if (mhz > best) best = mhz
			}
		}
		if (best > 0) cachedMaxFreq = best
		return best
	}

	// ---------------- دما ----------------

	private fun readCpuTemp(): Float? {
		try {
			val zones = File("/sys/class/thermal").listFiles() ?: return null
			var best: Float? = null
			for (zone in zones) {
				if (!zone.name.startsWith("thermal_zone")) continue
				val type = readTextFile(File(zone, "type"))?.lowercase() ?: continue
				val interesting = type.contains("cpu") || type.contains("soc") ||
					type.contains("tsens") || type.contains("apc") || type.contains("gpu")
				if (!interesting) continue

				val raw = readTextFile(File(zone, "temp"))?.toFloatOrNull() ?: continue
				var c = raw
				if (c > 1000f) c /= 1000f else if (c > 200f) c /= 10f
				if (c < 5f || c > 120f) continue

				val current = best
				if (current == null || c > current) best = c
			}
			return best
		} catch (t: Throwable) {
			return null
		}
	}

	private fun readBatteryTemp(context: Context): Float? {
		return try {
			val intent = context.applicationContext.registerReceiver(
				null,
				IntentFilter(Intent.ACTION_BATTERY_CHANGED)
			)
			val deci = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
			if (deci > 0) deci / 10f else null
		} catch (t: Throwable) {
			null
		}
	}

	private fun readThermalStatus(context: Context): Int {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return -1
		return try {
			val pm = context.getSystemService(PowerManager::class.java)
			pm?.currentThermalStatus ?: -1
		} catch (t: Throwable) {
			-1
		}
	}

	// ---------------- کمکی ----------------

	private fun readTextFile(file: File): String? {
		return try {
			if (!file.canRead()) null else file.readText().trim()
		} catch (t: Throwable) {
			null
		}
	}

	private fun readLongFile(path: String): Long? {
		return try {
			val f = File(path)
			if (!f.canRead()) null else f.readText().trim().toLongOrNull()
		} catch (t: Throwable) {
			null
		}
	}
}
