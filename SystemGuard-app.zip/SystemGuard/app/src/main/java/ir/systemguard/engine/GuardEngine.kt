package ir.systemguard.engine

import android.content.Context
import android.os.Build
import android.os.PowerManager
import ir.systemguard.data.GuardLog
import ir.systemguard.data.Prefs
import ir.systemguard.monitor.StatsSnapshot

/** مغز تصمیم‌گیری: وضعیت را می‌سنجد و در صورت لزوم پاکسازی می‌کند. */
class GuardEngine(private val context: Context) {

	enum class Level { OK, WATCH, WARN, CRITICAL }

	class Verdict(
		val level: Level,
		val reasons: List<String>,
		val cleaned: Boolean,
		val freedMb: Long,
		val killed: Int
	)

	private val cleaner = AppCleaner(context)
	private var lastCleanAt = 0L
	private var highCpuStreak = 0
	private var lastLevel = Level.OK

	fun evaluate(s: StatsSnapshot): Verdict {
		val reasons = ArrayList<String>()
		var level = Level.OK

		// ---------- رم ----------
		val freePercent = s.ramFreePercent
		val warnFree = Prefs.ramWarnFree(context)
		val critFree = Prefs.ramCritFree(context)

		if (freePercent <= critFree || s.lowMemory) {
			level = raise(level, Level.CRITICAL)
			reasons.add("رم تقریباً پر است (فقط $freePercent٪ آزاد – ${s.ramAvailMb} مگابایت)")
		} else if (freePercent <= warnFree) {
			level = raise(level, Level.WARN)
			reasons.add("رم در حال پر شدن است ($freePercent٪ آزاد)")
		} else if (freePercent <= warnFree + 6) {
			level = raise(level, Level.WATCH)
		}

		// ---------- حافطه مجازی / Memory extension ----------
		if (s.hasSwap && s.swapUsedPercent >= 80) {
			level = raise(level, Level.CRITICAL)
			reasons.add("حافطه مجازی ${s.swapUsedPercent}٪ پر شده – علت اصلی لگ و کندی همین است")
		} else if (s.hasSwap && s.swapUsedPercent >= 60) {
			level = raise(level, Level.WARN)
			reasons.add("حافطه مجازی ${s.swapUsedPercent}٪ درگیر است (جابجایی رم روی حافطه داخلی)")
		}

		// ---------- پردازنده ----------
		if (s.cpuLoad >= 85) highCpuStreak++ else highCpuStreak = 0
		if (highCpuStreak >= 3) {
			level = raise(level, Level.WARN)
			reasons.add("پردازنده مدتی است روی ${s.cpuLoad}٪ مانده")
		}

		// ---------- دما ----------
		val temp = s.bestTempC
		val tempWarn = Prefs.tempWarn(context)
		val tempCrit = Prefs.tempCrit(context)
		if (temp != null) {
			if (temp >= tempCrit) {
				level = raise(level, Level.CRITICAL)
				reasons.add("دمای ${fmt(temp)}° – پردازنده دارد خودرا خفه می‌کند (throttle)")
			} else if (temp >= tempWarn) {
				level = raise(level, Level.WARN)
				reasons.add("دمای ${fmt(temp)}° – گوشی داغ شده")
			}
		}

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && s.thermalStatus >= 0) {
			if (s.thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) {
				level = raise(level, Level.CRITICAL)
				reasons.add("سیستم وارد محدودیت حرارتی شده است")
			} else if (s.thermalStatus >= PowerManager.THERMAL_STATUS_MODERATE) {
				level = raise(level, Level.WARN)
				reasons.add("محدودیت حرارتی ملایم فعال شده")
			}
		}

		// ---------- لگ واقعی ----------
		if (s.jankPerSec >= 10f) {
			level = raise(level, Level.WARN)
			reasons.add("افت فریم محسوس است (${s.jankPerSec.toInt()} فریم در ثانیه جا می‌ماند)")
		}

		// ---------- حافطه داخلی ----------
		if (s.storageTotalGb > 0f && s.storageFreeGb < 5f) {
			level = raise(level, Level.WARN)
			reasons.add("حافطه داخلی کمتر از ۵ گیگ آزاد دارد")
		}

		// ---------- اقدام ----------
		var cleaned = false
		var freed = 0L
		var killed = 0

		val now = System.currentTimeMillis()
		val needsAction = level == Level.WARN || level == Level.CRITICAL
		val memoryPressure = freePercent <= warnFree || s.lowMemory ||
			(s.hasSwap && s.swapUsedPercent >= 60)
		val cooldownMs = Prefs.cooldownSec(context) * 1000L
		val cooldownPassed = now - lastCleanAt >= if (level == Level.CRITICAL) cooldownMs / 2 else cooldownMs

		if (Prefs.autoClean(context) && needsAction && memoryPressure && cooldownPassed) {
			val r = cleaner.clean(level == Level.CRITICAL)
			lastCleanAt = now
			cleaned = true
			freed = r.freedMb
			killed = r.killed
			GuardLog.add(
				context,
				if (level == Level.CRITICAL) GuardLog.CRIT else GuardLog.WARN,
				"پاکسازی خودکار: $killed برنامه از پس‌زمینه بسته شد، $freed مگابایت آزاد شد"
			)
		}

		if (level == Level.CRITICAL && lastLevel != Level.CRITICAL) {
			Prefs.bumpHangCount(context)
			GuardLog.add(context, GuardLog.CRIT, "خطر هنگ: " + reasons.joinToString(" • "))
		} else if (level == Level.WARN && lastLevel == Level.OK) {
			GuardLog.add(context, GuardLog.WARN, reasons.joinToString(" • "))
		}
		lastLevel = level

		return Verdict(level, reasons, cleaned, freed, killed)
	}

	fun manualClean(): AppCleaner.Result {
		val r = cleaner.clean(true)
		lastCleanAt = System.currentTimeMillis()
		GuardLog.add(
			context,
			GuardLog.INFO,
			"پاکسازی دستی: ${r.killed} برنامه بسته شد، ${r.freedMb} مگابایت آزاد شد"
		)
		return r
	}

	private fun raise(current: Level, candidate: Level): Level =
		if (candidate.ordinal > current.ordinal) candidate else current

	private fun fmt(v: Float): String = String.format("%.1f", v)
}
