package ir.systemguard.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import ir.systemguard.App
import ir.systemguard.R
import ir.systemguard.data.GuardLog
import ir.systemguard.data.GuardState
import ir.systemguard.data.Prefs
import ir.systemguard.engine.GuardEngine
import ir.systemguard.monitor.StatsCollector
import ir.systemguard.monitor.StatsSnapshot
import ir.systemguard.ui.MainActivity

/** سرویس دائمیٔ نگهبان: همیشه زنده می‌ماند و وضعیت را می‌پاید. */
class GuardService : Service() {

	private var thread: HandlerThread? = null
	private var handler: Handler? = null
	private var engine: GuardEngine? = null
	private var lastAlertAt = 0L
	private var tickCount = 0
	private var lastNotifiedLevel: GuardEngine.Level? = null

	private val loop = object : Runnable {
		override fun run() {
			try {
				tick()
			} catch (t: Throwable) {
				// هرگز نباید سرویس بمیرد
			}
			val delay = Prefs.intervalSec(this@GuardService).coerceIn(2, 60) * 1000L
			handler?.postDelayed(this, delay)
		}
	}

	override fun onCreate() {
		super.onCreate()
		engine = GuardEngine(this)
		val ht = HandlerThread("guard-loop")
		ht.start()
		thread = ht
		handler = Handler(ht.looper)
		GuardState.serviceRunning = true
		startInForeground(buildStatusNotification(null, null))
		WatchdogReceiver.schedule(this)
		handler?.post(loop)
	}

	override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
		when (intent?.action) {
			ACTION_STOP -> {
				Prefs.setGuardEnabled(this, false)
				GuardLog.add(this, GuardLog.INFO, "نگهبان توسط کاربر خاموش شد")
				WatchdogReceiver.cancel(this)
				stopSelf()
				return START_NOT_STICKY
			}

			ACTION_BOOST -> {
				handler?.post {
					GuardState.busy = true
					val result = engine?.manualClean()
					GuardState.busy = false
					if (result != null) {
						GuardState.lastManualFreedMb = result.freedMb
						GuardState.lastManualKilled = result.killed
					}
					tick()
				}
			}
		}
		return START_STICKY
	}

	override fun onBind(intent: Intent?): IBinder? = null

	override fun onTaskRemoved(rootIntent: Intent?) {
		// اگر کاربر برنامه را از لیست اخیر پاک کرد، دوباره بیاید بالا
		try {
			if (Prefs.guardEnabled(this)) WatchdogReceiver.schedule(this)
		} catch (t: Throwable) {
			// ignore
		}
		super.onTaskRemoved(rootIntent)
	}

	override fun onTrimMemory(level: Int) {
		super.onTrimMemory(level)
		if (level >= TRIM_MEMORY_RUNNING_LOW) {
			GuardLog.add(this, GuardLog.WARN, "سیستم اعلام کمبود حافطه کرد (سطح $level)")
			handler?.post { tick() }
		}
	}

	override fun onDestroy() {
		GuardState.serviceRunning = false
		handler?.removeCallbacksAndMessages(null)
		try {
			thread?.quitSafely()
		} catch (t: Throwable) {
			// ignore
		}
		thread = null
		handler = null
		super.onDestroy()
	}

	// ---------------- منطق اصلی ----------------

	private fun tick() {
		val snapshot = StatsCollector.sample(this)
		val verdict = engine?.evaluate(snapshot)

		GuardState.snapshot = snapshot
		GuardState.verdict = verdict
		GuardState.updatedAt = System.currentTimeMillis()

		tickCount++
		val levelChanged = verdict?.level != lastNotifiedLevel
		if (levelChanged || tickCount % 3 == 0 || verdict?.cleaned == true) {
			lastNotifiedLevel = verdict?.level
			notifyStatus(buildStatusNotification(snapshot, verdict))
		}

		if (verdict != null) maybeAlert(snapshot, verdict)
	}

	private fun maybeAlert(s: StatsSnapshot, v: GuardEngine.Verdict) {
		if (!Prefs.alerts(this)) return
		if (v.level != GuardEngine.Level.CRITICAL) return

		val now = System.currentTimeMillis()
		if (now - lastAlertAt < 5L * 60L * 1000L) return
		lastAlertAt = now

		val body = StringBuilder()
		for (r in v.reasons) body.append("• ").append(r).append("\n")
		if (v.cleaned) {
			body.append("• نگهبان ").append(v.freedMb).append(" مگابایت رم آزاد کرد\n")
		}
		val temp = s.bestTempC
		if (temp != null && temp >= Prefs.tempCrit(this)) {
			body.append("• پیشنهاد: بازی/فیلم را چند دقیقه قطع کن، روشنایی را کم کن و گوشی را از شارج جدا کن")
		}

		val alert = NotificationCompat.Builder(this, App.CH_ALERTS)
			.setSmallIcon(R.drawable.ic_shield)
			.setContentTitle("خطر هنگ / داغ شدن گوشی")
			.setContentText(v.reasons.firstOrNull() ?: "وضعیت بحرانی")
			.setStyle(NotificationCompat.BigTextStyle().bigText(body.toString().trim()))
			.setPriority(NotificationCompat.PRIORITY_HIGH)
			.setAutoCancel(true)
			.setContentIntent(openAppIntent())
			.build()

		try {
			val nm = getSystemService(NotificationManager::class.java)
			nm?.notify(ALERT_ID, alert)
		} catch (t: Throwable) {
			// ignore
		}
	}

	// ---------------- اعلان‌ها ----------------

	private fun startInForeground(notification: Notification) {
		try {
			if (Build.VERSION.SDK_INT >= 34) {
				ServiceCompat.startForeground(
					this,
					NOTIF_ID,
					notification,
					ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
				)
			} else {
				startForeground(NOTIF_ID, notification)
			}
		} catch (t: Throwable) {
			// ignore
		}
	}

	private fun notifyStatus(notification: Notification) {
		try {
			val nm = getSystemService(NotificationManager::class.java)
			nm?.notify(NOTIF_ID, notification)
		} catch (t: Throwable) {
			// ignore
		}
	}

	private fun buildStatusNotification(
		s: StatsSnapshot?,
		v: GuardEngine.Verdict?
	): Notification {
		val levelText = when (v?.level) {
			GuardEngine.Level.CRITICAL -> "وضعیت بحرانی"
			GuardEngine.Level.WARN -> "فشار روی سیستم"
			GuardEngine.Level.WATCH -> "در حال پایش"
			GuardEngine.Level.OK -> "سیستم روان است"
			null -> "در حال راه‌اندازی"
		}

		val line = if (s == null) {
			"پایش رم، پردازنده و دما فعال شد"
		} else {
			val temp = s.bestTempC
			val tempText = if (temp != null) String.format("%.0f°", temp) else "–"
			"رم ${s.ramFreePercent}٪ آزاد (${s.ramAvailMb}MB) • CPU ${s.cpuLoad}٪ • دما $tempText"
		}

		val big = StringBuilder(line)
		if (s != null && s.hasSwap) {
			big.append("\nحافطه مجازی: ").append(s.swapUsedPercent).append("٪ درگیر")
		}
		if (v != null && v.reasons.isNotEmpty()) {
			big.append("\n").append(v.reasons.joinToString("\n") { "• $it" })
		}
		if (v != null && v.cleaned) {
			big.append("\n✅ آخرین پاکسازی: ").append(v.freedMb).append(" مگابایت آزاد شد")
		}

		val boostIntent = Intent(this, GuardService::class.java).setAction(ACTION_BOOST)
		val stopIntent = Intent(this, GuardService::class.java).setAction(ACTION_STOP)

		return NotificationCompat.Builder(this, App.CH_STATUS)
			.setSmallIcon(R.drawable.ic_shield)
			.setContentTitle("نگهبان سیستم – $levelText")
			.setContentText(line)
			.setStyle(NotificationCompat.BigTextStyle().bigText(big.toString()))
			.setOngoing(true)
			.setOnlyAlertOnce(true)
			.setShowWhen(false)
			.setPriority(NotificationCompat.PRIORITY_LOW)
			.setContentIntent(openAppIntent())
			.addAction(R.drawable.ic_bolt, "پاکسازی", servicePendingIntent(2, boostIntent))
			.addAction(0, "توقف", servicePendingIntent(3, stopIntent))
			.build()
	}

	private fun openAppIntent(): PendingIntent {
		val intent = Intent(this, MainActivity::class.java)
			.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
		return PendingIntent.getActivity(this, 1, intent, piFlags())
	}

	private fun servicePendingIntent(code: Int, intent: Intent): PendingIntent {
		return PendingIntent.getService(this, code, intent, piFlags())
	}

	private fun piFlags(): Int {
		var flags = PendingIntent.FLAG_UPDATE_CURRENT
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			flags = flags or PendingIntent.FLAG_IMMUTABLE
		}
		return flags
	}

	companion object {
		const val ACTION_START = "ir.systemguard.action.START"
		const val ACTION_STOP = "ir.systemguard.action.STOP"
		const val ACTION_BOOST = "ir.systemguard.action.BOOST"

		private const val NOTIF_ID = 1001
		private const val ALERT_ID = 1002

		fun start(context: Context) {
			val intent = Intent(context, GuardService::class.java).setAction(ACTION_START)
			try {
				ContextCompat.startForegroundService(context, intent)
			} catch (t: Throwable) {
				// ignore
			}
		}

		fun boost(context: Context) {
			val intent = Intent(context, GuardService::class.java).setAction(ACTION_BOOST)
			try {
				ContextCompat.startForegroundService(context, intent)
			} catch (t: Throwable) {
				// ignore
			}
		}

		fun stop(context: Context) {
			val intent = Intent(context, GuardService::class.java).setAction(ACTION_STOP)
			try {
				ContextCompat.startForegroundService(context, intent)
			} catch (t: Throwable) {
				// ignore
			}
		}
	}
}
