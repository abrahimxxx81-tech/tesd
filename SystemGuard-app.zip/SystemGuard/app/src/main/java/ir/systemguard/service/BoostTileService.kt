package ir.systemguard.service

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi

/** دکمهٔ پاکسازی رم در پنل تنطیمات سریع. */
@RequiresApi(Build.VERSION_CODES.N)
class BoostTileService : TileService() {

	override fun onStartListening() {
		super.onStartListening()
		try {
			qsTile?.let {
				it.state = Tile.STATE_INACTIVE
				it.label = "پاکسازی رم"
				it.updateTile()
			}
		} catch (t: Throwable) {
			// ignore
		}
	}

	override fun onClick() {
		super.onClick()
		try {
			GuardService.boost(applicationContext)
		} catch (t: Throwable) {
			// ignore
		}
	}
}
