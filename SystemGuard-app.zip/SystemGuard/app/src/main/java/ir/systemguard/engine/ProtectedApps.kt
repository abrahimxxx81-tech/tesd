package ir.systemguard.engine

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager

/** برنامه‌هایی که هرگز نباید بسته شوند. */
object ProtectedApps {

	private val CORE = setOf(
		"android",
		"com.android.systemui",
		"com.android.phone",
		"com.android.server.telecom",
		"com.android.settings",
		"com.android.bluetooth",
		"com.android.nfc",
		"com.android.keychain",
		"com.android.providers.settings",
		"com.android.providers.telephony",
		"com.android.providers.contacts",
		"com.android.providers.media",
		"com.android.providers.media.module",
		"com.android.providers.downloads",
		"com.android.deskclock",
		"com.google.android.deskclock",
		"com.google.android.gms",
		"com.google.android.gsf",
		"com.android.vending",
		// MIUI / Xiaomi
		"com.miui.home",
		"com.mi.android.globallauncher",
		"com.miui.securitycenter",
		"com.miui.securityadd",
		"com.miui.powerkeeper",
		"com.miui.notification",
		"com.miui.system",
		"com.xiaomi.xmsf",
		"com.xiaomi.finddevice",
		"com.lbe.security.miui",
		"com.miui.securitycore"
	)

	/** پیشنهاد پیش‌فرض برای لیست محافطت‌شده کاربر (پیام‌رسان‌ها). */
	val SUGGESTED = listOf(
		"org.telegram.messenger",
		"org.telegram.plus",
		"com.whatsapp",
		"ir.eitaa.messenger",
		"ir.resaneh1.iptv",
		"ir.nasim",
		"com.android.deskclock",
		"com.google.android.deskclock"
	)

	fun build(context: Context): Set<String> {
		val out = HashSet<String>(CORE)
		out.add(context.packageName)

		// لانچر پیش‌فرض
		try {
			val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
			val info = context.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
			val pkg = info?.activityInfo?.packageName
			if (!pkg.isNullOrEmpty()) out.add(pkg)
		} catch (t: Throwable) {
			// ignore
		}

		// کیبورد فعال
		try {
			val ime = Settings.Secure.getString(
				context.contentResolver,
				Settings.Secure.DEFAULT_INPUT_METHOD
			)
			if (!ime.isNullOrEmpty()) out.add(ime.substringBefore("/"))
		} catch (t: Throwable) {
			// ignore
		}

		// تلفن و پیامک پیش‌فرض
		try {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
				val tm = context.getSystemService(TelecomManager::class.java)
				val dialer = tm?.defaultDialerPackage
				if (!dialer.isNullOrEmpty()) out.add(dialer)
			}
		} catch (t: Throwable) {
			// ignore
		}
		try {
			val sms = Telephony.Sms.getDefaultSmsPackage(context)
			if (!sms.isNullOrEmpty()) out.add(sms)
		} catch (t: Throwable) {
			// ignore
		}

		return out
	}
}
