package ir.systemguard.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import ir.systemguard.data.GuardState
import ir.systemguard.data.Prefs

/**
 * نگهبانِ نگهبان.
 * هر ۱۵ دقیقه بررسی می‌کند سرویس زنده است یا نه؛ اگر سیستم آن را کشته باشد، دوباره بالا می‌آورد.
 */
class WatchdogReceiver : BroadcastReceiver() {

	override fun onReceive(context: Context, intent: Intent?) {
		if (!Prefs.guardEnabled(context)) return
		try {
			if (!GuardState.serviceRunning) {
				GuardService.start(context)
			}
			schedule(context)
		} catch (t: Throwable) {
			// ignore
		}
	}

	companion object {
		private const val INTERVAL_MS = 15L * 60L * 1000L

		fun schedule(context: Context) {
			try {
				val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
				am.set(
					AlarmManager.ELAPSED_REALTIME,
					SystemClock.elapsedRealtime() + INTERVAL_MS,
					pendingIntent(context)
				)
			} catch (t: Throwable) {
				// ignore
			}
		}

		fun cancel(context: Context) {
			try {
				val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
				am.cancel(pendingIntent(context))
			} catch (t: Throwable) {
				// ignore
			}
		}

		private fun pendingIntent(context: Context): PendingIntent {
			val intent = Intent(context, WatchdogReceiver::class.java)
			var flags = PendingIntent.FLAG_UPDATE_CURRENT
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
				flags = flags or PendingIntent.FLAG_IMMUTABLE
			}
			return PendingIntent.getBroadcast(context, 991, intent, flags)
		}
	}
}
