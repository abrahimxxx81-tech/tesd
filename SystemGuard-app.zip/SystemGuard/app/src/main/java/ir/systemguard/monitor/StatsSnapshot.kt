package ir.systemguard.monitor

/** یک عکس لحطه‌ای از وضعیت گوشی. */
class StatsSnapshot(
	val timestamp: Long,
	val ramTotalKb: Long,
	val ramAvailKb: Long,
	val lowMemory: Boolean,
	val swapTotalKb: Long,
	val swapFreeKb: Long,
	val cpuLoad: Int,
	val cpuLoadApprox: Boolean,
	val coreFreqMhz: List<Int>,
	val cpuMaxFreqMhz: Int,
	val cpuTempC: Float?,
	val batteryTempC: Float?,
	val thermalStatus: Int,
	val storageFreeGb: Float,
	val storageTotalGb: Float,
	val jankPerSec: Float
) {

	val ramFreePercent: Int
		get() = if (ramTotalKb > 0) ((ramAvailKb * 100L) / ramTotalKb).toInt() else 100

	val ramUsedPercent: Int
		get() = 100 - ramFreePercent

	val ramTotalMb: Long get() = ramTotalKb / 1024L
	val ramAvailMb: Long get() = ramAvailKb / 1024L

	val hasSwap: Boolean get() = swapTotalKb > 0L

	val swapUsedPercent: Int
		get() = if (swapTotalKb > 0)
			(((swapTotalKb - swapFreeKb) * 100L) / swapTotalKb).toInt()
		else 0

	val swapTotalMb: Long get() = swapTotalKb / 1024L
	val swapUsedMb: Long get() = (swapTotalKb - swapFreeKb) / 1024L

	/** بهترین دمای در دسترس (اول پردازنده، وگرنه باتری). */
	val bestTempC: Float?
		get() = cpuTempC ?: batteryTempC
}
