package ir.systemguard

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class App : Application() {

	override fun onCreate() {
		super.onCreate()
		createChannels()
	}

	private fun createChannels() {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
		try {
			val nm = getSystemService(NotificationManager::class.java) ?: return

			val status = NotificationChannel(
				CH_STATUS,
				getString(R.string.ch_status),
				NotificationManager.IMPORTANCE_LOW
			)
			status.setShowBadge(false)
			status.enableVibration(false)
			status.setSound(null, null)

			val alerts = NotificationChannel(
				CH_ALERTS,
				getString(R.string.ch_alerts),
				NotificationManager.IMPORTANCE_HIGH
			)
			alerts.enableVibration(true)

			nm.createNotificationChannel(status)
			nm.createNotificationChannel(alerts)
		} catch (t: Throwable) {
			// ignore
		}
	}

	companion object {
		const val CH_STATUS = "guard_status"
		const val CH_ALERTS = "guard_alerts"
	}
}
