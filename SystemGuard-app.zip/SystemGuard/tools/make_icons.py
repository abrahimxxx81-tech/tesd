#!/usr/bin/env python3
"""Generates launcher icons (shield + bolt) for the SystemGuard app."""
import os
from PIL import Image, ImageDraw

BASE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "app", "src", "main", "res")

SIZES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

BG_TOP = (18, 32, 60)
BG_BOTTOM = (10, 16, 28)
SHIELD = (76, 141, 255)
SHIELD_DARK = (37, 64, 110)
BOLT = (255, 214, 92)


def gradient(size):
    img = Image.new("RGB", (size, size), BG_BOTTOM)
    draw = ImageDraw.Draw(img)
    for y in range(size):
        t = y / max(1, size - 1)
        color = tuple(int(BG_TOP[i] + (BG_BOTTOM[i] - BG_TOP[i]) * t) for i in range(3))
        draw.line([(0, y), (size, y)], fill=color)
    return img


def shield_points(size):
    w = size * 0.56
    h = size * 0.64
    cx = size / 2.0
    top = (size - h) / 2.0
    left = cx - w / 2.0
    right = cx + w / 2.0
    shoulder = top + h * 0.52
    return [
        (cx, top),
        (right, top + h * 0.14),
        (right, shoulder),
        (cx, top + h),
        (left, shoulder),
        (left, top + h * 0.14),
    ]


def bolt_points(size):
    cx = size / 2.0
    cy = size / 2.0
    u = size * 0.085
    return [
        (cx + 0.55 * u, cy - 2.45 * u),
        (cx - 1.65 * u, cy + 0.30 * u),
        (cx - 0.20 * u, cy + 0.30 * u),
        (cx - 0.75 * u, cy + 2.45 * u),
        (cx + 1.65 * u, cy - 0.45 * u),
        (cx + 0.15 * u, cy - 0.45 * u),
    ]


def draw_icon(size, round_icon):
    scale = 4
    big = size * scale
    img = gradient(big).convert("RGBA")
    draw = ImageDraw.Draw(img)

    pts = shield_points(big)
    draw.polygon(pts, fill=SHIELD)
    inner = [( (x - big / 2.0) * 0.80 + big / 2.0,
               (y - big / 2.0) * 0.80 + big / 2.0) for x, y in pts]
    draw.polygon(inner, fill=SHIELD_DARK)
    draw.polygon(bolt_points(big), fill=BOLT)

    mask = Image.new("L", (big, big), 0)
    mdraw = ImageDraw.Draw(mask)
    if round_icon:
        mdraw.ellipse([0, 0, big - 1, big - 1], fill=255)
    else:
        radius = int(big * 0.22)
        mdraw.rounded_rectangle([0, 0, big - 1, big - 1], radius=radius, fill=255)
    img.putalpha(mask)

    return img.resize((size, size), Image.LANCZOS)


def main():
    for folder, size in SIZES.items():
        target = os.path.join(BASE, folder)
        os.makedirs(target, exist_ok=True)
        draw_icon(size, False).save(os.path.join(target, "ic_launcher.png"))
        draw_icon(size, True).save(os.path.join(target, "ic_launcher_round.png"))
        print("wrote", folder, size)


if __name__ == "__main__":
    main()
